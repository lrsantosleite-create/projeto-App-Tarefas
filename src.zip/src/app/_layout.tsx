import { Stack } from "expo-router";
import { useState } from 'react';

export default function Layout( ) {
  return (
    <Stack>
      <Stack.Screen 
      name="index" 
      options={{ 
        title: "Agendador de Tarefas" ,
       }}
       />

       <Stack.Screen 
      name="nova_tarefa" 
      options={{ 
        title: "Nova Tarefa" ,
       }}
       />

    </Stack>
  );
}

const [tarefa, setTarefa] = useState('');
const [tarefas, setTarefas] = useState([
  { id: 1, texto: 'Estudar React-Native', concluida: false },
  { id: 2, texto: 'Aprender useState', concluida: false },
]);
